import sqlite3

conn = sqlite3.connect("celebrities.db")
c = conn.cursor()

# Create the member_login table
sql = """CREATE TABLE member_login(
            memberID integer PRIMARY KEY,
            username text,
            password text
        )"""
c.execute(sql)

# Insert two login accounts (you + teammate)
data1 = (1, "lam", "mypassword")
data2 = (2, "sar", "herpassword")

c.execute("INSERT INTO member_login VALUES (?, ?, ?)", data1)
c.execute("INSERT INTO member_login VALUES (?, ?, ?)", data2)

conn.commit()
conn.close()

print("member_login table created and data inserted.")
