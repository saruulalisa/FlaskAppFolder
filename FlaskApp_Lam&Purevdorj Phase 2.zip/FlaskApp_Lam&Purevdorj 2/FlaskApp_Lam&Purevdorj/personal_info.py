import sqlite3

conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()

sql = "INSERT INTO members VALUES (?, ?, ?, ?, ?, ?)"

data1 = (1, "Lam", "Dao", 21, "lamdao@dukes.jmu.edu", "I am an ISAT student who likes coding.")

data2 = (2, "Saruul", "Purevdorj", 20, "saruulalisa@gmail.com", "I am an ISAT major")

cursor.execute(sql, data1)
cursor.execute(sql, data2)

conn.commit()
conn.close()