import sqlite3

conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()

sql = "insert into celebs values (?, ?, ?, ?, ?, ?, ?)"

data = (1, "Angelina", "Jolie", 40, "angie@hollywood.us",
        "https://s3.amazonaws.com/isat3402021/aj.jpg",
        "Angelina Jolie is an American actress, director, and humanitarian.")
cursor.execute(sql, data)

data = (2, "Brad", "Pitt", 51, "brad@hollywood.us",
        "https://s3.amazonaws.com/isat3402021/bp.jpg",
        "Brad Pitt is an American actor and producer known for many award-winning films.")
cursor.execute(sql, data)

data = (3, "Snow", "White", 21, "sw@disney.org",
        "https://s3.amazonaws.com/isat3402021/sw.jpg",
        "Snow White is a classic Disney character known for her kindness and friendship with the dwarfs.")
cursor.execute(sql, data)

data = (4, "Darth", "Vader", 29, "dv@darkside.me",
        "https://s3.amazonaws.com/isat3402021/dv.jpg",
        "Darth Vader is a powerful Star Wars character who becomes a Sith Lord.")
cursor.execute(sql, data)

data = (5, "Taylor", "Swift", 25, "ts@1989.us",
        "https://s3.amazonaws.com/isat3402021/ts.jpg",
        "Taylor Swift is an American singer-songwriter famous for her storytelling music.")
cursor.execute(sql, data)

data = (6, "Beyonce", "Knowles", 34, "beyonce@jayz.me",
        "https://s3.amazonaws.com/isat3402021/bk.jpg",
        "Beyonce Knowles is a Grammy-winning performer and cultural icon.")
cursor.execute(sql, data)

data = (7, "Selena", "Gomez", 23, "selena@hollywood.us",
        "https://s3.amazonaws.com/isat3402021/sg.jpg",
        "Selena Gomez is an American actress and singer who began her career on Disney Channel.")
cursor.execute(sql, data)

data = (8, "Stephen", "Curry", 27, "steph@golden.bb",
        "https://s3.amazonaws.com/isat3402021/sc.jpg",
        "Stephen Curry is a professional basketball player known for his three-point shooting.")
cursor.execute(sql, data)

conn.commit()
conn.close()
