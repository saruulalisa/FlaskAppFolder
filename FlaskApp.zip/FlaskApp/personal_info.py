import sqlite3

conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
sql = "insert into members values (?, ?, ?, ?, ?)"
data = (1, "Saruul", "Purevdorj", 20, "saruulalisa@gmail.com", "I am an ISAT major")

conn. commit()
conn.close()
